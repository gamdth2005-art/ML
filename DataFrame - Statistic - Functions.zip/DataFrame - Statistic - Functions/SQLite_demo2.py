#Viết hàm trả về danh sách Customer có tham gia >=N Invoice
import sqlite3
import pandas as pd

def customers_with_min_invoices_and_total_value(db_path, n_invoices):

    conn = sqlite3.connect(db_path)
    invoices = pd.read_sql_query('SELECT CustomerId, Total FROM Invoice;', conn)
    conn.close()

    grouped = (
        invoices.groupby('CustomerId')
        .agg(InvoiceCount=('Total', 'count'), TotalValue=('Total', 'sum'))
        .reset_index()
    )

    filtered = grouped[grouped['InvoiceCount'] >= n_invoices] \
        .sort_values(by='TotalValue', ascending=False) \
        .reset_index(drop=True)

    result = filtered[['CustomerId', 'TotalValue']]

    return result

# --- sử dụng ---
db_path = '../databases/Chinook_Sqlite.sqlite'
n_invoices = int(input("Nhập số Invoice tối thiểu: "))

customers = customers_with_min_invoices_and_total_value(db_path, n_invoices)
print(customers)
