#Đầu vào df, đâù ra là 3 id của sản phẩm có giá trị bán ra cao nhất
import pandas as pd

def top_3_products_by_sales(df):
    df = df.copy()
    df['TotalSales'] = df['UnitPrice'] * df['Quantity'] * (1 - df['Discount'])

    product_sales = (
        df.groupby('ProductID', as_index=False)['TotalSales']
          .sum()
          .rename(columns={'TotalSales': 'TotalSales'})
    )

    top3 = product_sales.sort_values(
        by='TotalSales', ascending=False
    ).head(3).reset_index(drop=True)

    return top3

df = pd.read_csv('../datasets/SalesTransactions/SalesTransactions.csv')

top_products = top_3_products_by_sales(df)
print("3 sản phẩm có giá trị bán ra cao nhất là:")
print(top_products)
