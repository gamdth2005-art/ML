#slide 38
import pandas as pd

def find_orders_within_range(df, minValue, maxValue, sortType):
    order_totals = df.groupby('OrderID').apply(lambda x: (x['UnitPrice'] * x['Quantity'] * (1 - x['Discount'])).sum())
    orders_within_range = order_totals[(order_totals >= minValue) & (order_totals <= maxValue)]
    unique_orders = df[df['OrderID'].isin(orders_within_range.index)]['OrderID'].drop_duplicates().tolist()
    orders_sorted = orders_within_range.sort_values(by='TotalValue', ascending=sortType ).reset_index(drop=True)

    return unique_orders

df=pd.read_csv('../datasets/SalesTransactions/SalesTransactions.csv')

minValue=float(input("Min: "))
maxValue=float(input("Max: "))
sortType = input("Sắp xếp tăng dần?500 (y/n): ").lower().strip() == 'y'

result=find_orders_within_range(df, minValue, maxValue, sortType)
print("Danh sach hoa don trong pham vi gia tri tu", minValue, "den", maxValue, 'la', result)
