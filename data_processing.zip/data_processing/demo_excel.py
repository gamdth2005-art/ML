import pandas as pd

dataframe=pd.read_excel("../datasets/SalesTransactions/SalesTransactions.xlsx")

print(dataframe)